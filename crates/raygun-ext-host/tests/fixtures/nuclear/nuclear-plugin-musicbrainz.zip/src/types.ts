export type MusicBrainzArea = {
  id: string;
  name: string;
  'sort-name': string;
  'iso-3166-1-codes'?: string[];
};

export type MusicBrainzLifeSpan = {
  begin: string | null;
  end: string | null;
  ended: boolean;
};

export type MusicBrainzAlias = {
  name: string;
  'sort-name': string;
  type: string | null;
  locale: string | null;
  primary: boolean | null;
};

export type MusicBrainzTag = {
  name: string;
  count: number;
};

export type MusicBrainzGenre = {
  id: string;
  name: string;
  disambiguation: string;
  count: number;
};

export type MusicBrainzRating = {
  value: number | null;
  'votes-count': number;
};

export type MusicBrainzUrl = {
  id: string;
  resource: string;
};

export type MusicBrainzRelation = {
  type: string;
  'type-id': string;
  direction: string;
  url: MusicBrainzUrl;
  attributes: string[];
  'source-credit': string;
  'target-credit': string;
  'target-type': string;
  begin: string | null;
  end: string | null;
  ended: boolean;
};

export type MusicBrainzArtistCredit = {
  name: string;
  joinphrase: string;
  artist: {
    id: string;
    name: string;
    'sort-name': string;
    type?: string;
    disambiguation?: string;
  };
};

export type MusicBrainzArtist = {
  id: string;
  name: string;
  'sort-name': string;
  type: string | null;
  'type-id'?: string;
  disambiguation: string;
  country?: string;
  gender?: string | null;
  area?: MusicBrainzArea;
  'begin-area'?: MusicBrainzArea | null;
  'life-span'?: MusicBrainzLifeSpan;
  aliases?: MusicBrainzAlias[];
  tags?: MusicBrainzTag[];
  genres?: MusicBrainzGenre[];
  rating?: MusicBrainzRating;
  relations?: MusicBrainzRelation[];
};

export type MusicBrainzCoverArtArchive = {
  artwork: boolean;
  front: boolean;
  back: boolean;
  darkened: boolean;
  count: number;
};

export type MusicBrainzRecording = {
  id: string;
  title: string;
  length: number | null;
  video: boolean;
  disambiguation: string;
  'first-release-date'?: string;
  'artist-credit'?: MusicBrainzArtistCredit[];
};

export type MusicBrainzTrack = {
  id: string;
  number: string;
  title: string;
  position: number;
  length: number | null;
  'artist-credit'?: MusicBrainzArtistCredit[];
  recording: MusicBrainzRecording;
};

export type MusicBrainzMedia = {
  format: string | null;
  position: number;
  title: string;
  'track-count': number;
  'track-offset': number;
  tracks?: MusicBrainzTrack[];
};

export type MusicBrainzRelease = {
  id: string;
  title: string;
  status?: string;
  date?: string;
  country?: string;
  barcode?: string;
  'cover-art-archive'?: MusicBrainzCoverArtArchive;
  'artist-credit'?: MusicBrainzArtistCredit[];
  media?: MusicBrainzMedia[];
  'release-events'?: Array<{
    date: string;
    area: MusicBrainzArea;
  }>;
  'text-representation'?: {
    language: string;
    script: string;
  };
};

export type MusicBrainzReleaseGroup = {
  id: string;
  title: string;
  'primary-type'?: string;
  'primary-type-id'?: string;
  'secondary-types'?: string[];
  'secondary-type-ids'?: string[];
  'first-release-date'?: string;
  disambiguation: string;
  'artist-credit'?: MusicBrainzArtistCredit[];
  releases?: MusicBrainzRelease[];
  tags?: MusicBrainzTag[];
  genres?: MusicBrainzGenre[];
};

export type MusicBrainzArtistSearchResult = MusicBrainzArtist & {
  score: number;
};

export type MusicBrainzReleaseGroupSearchResult = MusicBrainzReleaseGroup & {
  score: number;
};

export type MusicBrainzRecordingSearchResult = MusicBrainzRecording & {
  score: number;
  releases?: MusicBrainzRelease[];
};

type MusicBrainzSearchResultBase = {
  created: string;
  count: number;
  offset: number;
};

export type MusicBrainzArtistSearchResponse = MusicBrainzSearchResultBase & {
  artists: MusicBrainzArtistSearchResult[];
};

export type MusicBrainzReleaseGroupSearchResponse =
  MusicBrainzSearchResultBase & {
    'release-groups': MusicBrainzReleaseGroupSearchResult[];
  };

export type MusicBrainzRecordingSearchResponse = MusicBrainzSearchResultBase & {
  recordings: MusicBrainzRecordingSearchResult[];
};

export type MusicBrainzBrowseReleaseGroupsResponse = {
  'release-group-count': number;
  'release-group-offset': number;
  'release-groups': MusicBrainzReleaseGroup[];
};

export type MusicBrainzBrowseReleasesResponse = {
  'release-count': number;
  'release-offset': number;
  releases: MusicBrainzRelease[];
};

export type WikipediaSummary = {
  title: string;
  extract: string;
  extract_html?: string;
  description?: string;
  thumbnail?: {
    source: string;
    width: number;
    height: number;
  };
  originalimage?: {
    source: string;
    width: number;
    height: number;
  };
  content_urls?: {
    desktop: { page: string };
    mobile: { page: string };
  };
};

export type WikidataEntity = {
  type: string;
  id: string;
  sitelinks?: Record<
    string,
    {
      site: string;
      title: string;
    }
  >;
};

export type WikidataResponse = {
  entities: Record<string, WikidataEntity>;
};
