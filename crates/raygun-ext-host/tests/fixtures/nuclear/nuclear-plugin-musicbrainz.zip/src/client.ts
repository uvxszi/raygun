import type { FetchFunction } from '@nuclearplayer/plugin-sdk';

import {
  DEFAULT_BROWSE_LIMIT,
  DEFAULT_SEARCH_LIMIT,
  MUSICBRAINZ_API_BASE,
  RATE_LIMIT_INTERVAL_MS,
  USER_AGENT,
} from './config';
import type {
  MusicBrainzArtist,
  MusicBrainzArtistSearchResponse,
  MusicBrainzBrowseReleaseGroupsResponse,
  MusicBrainzBrowseReleasesResponse,
  MusicBrainzRecordingSearchResponse,
  MusicBrainzReleaseGroup,
  MusicBrainzReleaseGroupSearchResponse,
} from './types';

export class MusicBrainzClient {
  #fetch: FetchFunction;
  #lastRequestTime = 0;
  // Serializes outgoing requests with a minimum interval to stay under the rate limit
  #queue: Array<{
    resolve: (value: void) => void;
    reject: (reason: unknown) => void;
  }> = [];
  #processing = false;

  constructor(fetchFn: FetchFunction) {
    this.#fetch = fetchFn;
  }

  async #waitForRateLimit(): Promise<void> {
    return new Promise((resolve, reject) => {
      this.#queue.push({ resolve, reject });
      if (!this.#processing) {
        this.#processQueue();
      }
    });
  }

  async #processQueue(): Promise<void> {
    this.#processing = true;
    while (this.#queue.length > 0) {
      const elapsed = Date.now() - this.#lastRequestTime;
      if (elapsed < RATE_LIMIT_INTERVAL_MS) {
        await new Promise((resolve) =>
          setTimeout(resolve, RATE_LIMIT_INTERVAL_MS - elapsed),
        );
      }
      this.#lastRequestTime = Date.now();
      const next = this.#queue.shift();
      next?.resolve();
    }
    this.#processing = false;
  }

  async #get<T>(path: string): Promise<T> {
    await this.#waitForRateLimit();
    const separator = path.includes('?') ? '&' : '?';
    const url = `${MUSICBRAINZ_API_BASE}${path}${separator}fmt=json`;
    const response = await this.#fetch(url, {
      headers: { 'User-Agent': USER_AGENT, Accept: 'application/json' },
    });
    if (!response.ok) {
      throw new Error(
        `MusicBrainz API error: ${response.status} ${response.statusText}`,
      );
    }
    return response.json();
  }

  async searchArtists(
    query: string,
    limit = DEFAULT_SEARCH_LIMIT,
  ): Promise<MusicBrainzArtistSearchResponse> {
    return this.#get(
      `/artist?query=${encodeURIComponent(query)}&limit=${limit}&dismax=true`,
    );
  }

  async searchReleaseGroups(
    query: string,
    limit = DEFAULT_SEARCH_LIMIT,
  ): Promise<MusicBrainzReleaseGroupSearchResponse> {
    return this.#get(
      `/release-group?query=${encodeURIComponent(query)}&limit=${limit}&dismax=true`,
    );
  }

  async searchRecordings(
    query: string,
    limit = DEFAULT_SEARCH_LIMIT,
  ): Promise<MusicBrainzRecordingSearchResponse> {
    return this.#get(
      `/recording?query=${encodeURIComponent(query)}&limit=${limit}&dismax=true`,
    );
  }

  async getArtist(mbid: string): Promise<MusicBrainzArtist> {
    return this.#get(
      `/artist/${mbid}?inc=aliases+tags+genres+ratings+url-rels`,
    );
  }

  async getReleaseGroup(mbid: string): Promise<MusicBrainzReleaseGroup> {
    return this.#get(`/release-group/${mbid}?inc=artist-credits+tags+genres`);
  }

  async browseArtistReleaseGroups(
    artistMbid: string,
    limit = DEFAULT_BROWSE_LIMIT,
    offset = 0,
  ): Promise<MusicBrainzBrowseReleaseGroupsResponse> {
    return this.#get(
      `/release-group?artist=${artistMbid}&type=album|ep&limit=${limit}&offset=${offset}&inc=artist-credits`,
    );
  }

  async browseReleaseGroupReleases(
    releaseGroupMbid: string,
  ): Promise<MusicBrainzBrowseReleasesResponse> {
    return this.#get(
      `/release?release-group=${releaseGroupMbid}&status=official&limit=1&inc=recordings+artist-credits+media`,
    );
  }
}
