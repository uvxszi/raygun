import type {
  Album,
  AlbumRef,
  ArtistBio,
  ArtistRef,
  ArtworkSet,
  Track,
  TrackRef,
} from '@nuclearplayer/plugin-sdk';

import { PROVIDER_ID } from './config';
import {
  releaseCoverUrl,
  releaseGroupCoverUrl,
  releaseGroupThumbnailUrl,
  releaseThumbnailUrl,
} from './cover-art';
import type {
  MusicBrainzArtist,
  MusicBrainzArtistCredit,
  MusicBrainzArtistSearchResult,
  MusicBrainzRecordingSearchResult,
  MusicBrainzRelease,
  MusicBrainzReleaseGroup,
  MusicBrainzReleaseGroupSearchResult,
  MusicBrainzTrack,
  WikipediaSummary,
} from './types';

const musicbrainzSource = (mbid: string) => ({
  provider: PROVIDER_ID,
  id: mbid,
});

const releaseGroupArtwork = (releaseGroupMbid: string): ArtworkSet => ({
  items: [
    { url: releaseGroupCoverUrl(releaseGroupMbid), purpose: 'cover' },
    { url: releaseGroupThumbnailUrl(releaseGroupMbid), purpose: 'thumbnail' },
  ],
});

const releaseArtwork = (releaseMbid: string): ArtworkSet => ({
  items: [
    { url: releaseCoverUrl(releaseMbid), purpose: 'cover' },
    { url: releaseThumbnailUrl(releaseMbid), purpose: 'thumbnail' },
  ],
});

const mapArtistCredits = (credits: MusicBrainzArtistCredit[]): ArtistRef[] =>
  credits.map((credit) => ({
    name: credit.artist.name,
    disambiguation: credit.artist.disambiguation,
    source: musicbrainzSource(credit.artist.id),
  }));

export const mapArtistSearchResult = (
  artist: MusicBrainzArtistSearchResult,
): ArtistRef => ({
  name: artist.name,
  disambiguation: artist.disambiguation || undefined,
  source: musicbrainzSource(artist.id),
});

export const mapReleaseGroupSearchResult = (
  releaseGroup: MusicBrainzReleaseGroupSearchResult,
): AlbumRef => ({
  title: releaseGroup.title,
  artists: releaseGroup['artist-credit']
    ? mapArtistCredits(releaseGroup['artist-credit'])
    : undefined,
  artwork: releaseGroupArtwork(releaseGroup.id),
  source: musicbrainzSource(releaseGroup.id),
});

export const mapRecordingSearchResult = (
  recording: MusicBrainzRecordingSearchResult,
): Track => {
  const firstRelease = recording.releases?.[0];
  return {
    title: recording.title,
    artists: (recording['artist-credit'] ?? []).map((credit) => ({
      name: credit.artist.name,
      roles: [],
      source: musicbrainzSource(credit.artist.id),
    })),
    durationMs: recording.length ?? undefined,
    album: firstRelease
      ? {
          title: firstRelease.title,
          artwork: releaseArtwork(firstRelease.id),
          source: musicbrainzSource(firstRelease.id),
        }
      : undefined,
    source: musicbrainzSource(recording.id),
  };
};

const buildWikipediaArtwork = (
  wikipedia: WikipediaSummary,
): ArtworkSet | undefined => {
  if (!wikipedia.thumbnail) {
    return undefined;
  }

  const items: ArtworkSet['items'] = [
    { url: wikipedia.thumbnail.source, purpose: 'cover' },
  ];

  if (wikipedia.originalimage) {
    items.push({ url: wikipedia.originalimage.source, purpose: 'background' });
  }

  return { items };
};

export const mapArtistToArtistBio = (
  artist: MusicBrainzArtist,
  wikipedia: WikipediaSummary | null,
): ArtistBio => ({
  name: artist.name,
  disambiguation: artist.disambiguation || undefined,
  bio: wikipedia?.extract,
  artwork: wikipedia ? buildWikipediaArtwork(wikipedia) : undefined,
  tags: artist.genres
    ?.filter((genre) => genre.count > 0)
    .map((genre) => genre.name),
  source: musicbrainzSource(artist.id),
});

export const mapReleaseGroupToAlbumRef = (
  releaseGroup: MusicBrainzReleaseGroup,
): AlbumRef => ({
  title: releaseGroup.title,
  artists: releaseGroup['artist-credit']
    ? mapArtistCredits(releaseGroup['artist-credit'])
    : undefined,
  artwork: releaseGroupArtwork(releaseGroup.id),
  source: musicbrainzSource(releaseGroup.id),
});

const mapMusicBrainzTrackToTrackRef = (track: MusicBrainzTrack): TrackRef => ({
  title: track.recording.title,
  artists: track['artist-credit']
    ? mapArtistCredits(track['artist-credit'])
    : track.recording['artist-credit']
      ? mapArtistCredits(track.recording['artist-credit'])
      : [],
  source: musicbrainzSource(track.recording.id),
});

const parseReleaseDate = (
  dateStr: string,
): { precision: 'year' | 'month' | 'day'; dateIso: string } | undefined => {
  if (!dateStr) {
    return undefined;
  }
  const parts = dateStr.split('-');
  if (parts.length === 3) {
    return { precision: 'day', dateIso: dateStr };
  }
  if (parts.length === 2) {
    return { precision: 'month', dateIso: dateStr };
  }
  return { precision: 'year', dateIso: dateStr };
};

export const mapReleaseToAlbum = (
  releaseGroup: MusicBrainzReleaseGroup,
  release: MusicBrainzRelease,
): Album => ({
  title: releaseGroup.title,
  artists: (
    releaseGroup['artist-credit'] ??
    release['artist-credit'] ??
    []
  ).map((credit) => ({
    name: credit.artist.name,
    roles: [],
    source: musicbrainzSource(credit.artist.id),
  })),
  tracks: (release.media ?? []).flatMap((medium) =>
    (medium.tracks ?? []).map(mapMusicBrainzTrackToTrackRef),
  ),
  releaseDate: releaseGroup['first-release-date']
    ? parseReleaseDate(releaseGroup['first-release-date'])
    : undefined,
  genres: releaseGroup.genres
    ?.filter((genre) => genre.count > 0)
    .map((genre) => genre.name),
  artwork: releaseGroupArtwork(releaseGroup.id),
  source: musicbrainzSource(releaseGroup.id),
});
