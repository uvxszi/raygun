import type { FetchFunction } from '@nuclearplayer/plugin-sdk';

import { WIKIDATA_API_BASE, WIKIPEDIA_API_BASE } from './config';
import type {
  MusicBrainzRelation,
  WikidataResponse,
  WikipediaSummary,
} from './types';

export class WikipediaClient {
  #fetch: FetchFunction;

  constructor(fetchFn: FetchFunction) {
    this.#fetch = fetchFn;
  }

  #extractWikidataId(relations: MusicBrainzRelation[]): string | null {
    const wikidataRel = relations.find(
      (relation) => relation.type === 'wikidata',
    );
    if (!wikidataRel) {
      return null;
    }
    const url = wikidataRel.url.resource;
    const match = url.match(/wikidata\.org\/wiki\/(Q\d+)/);
    return match?.[1] ?? null;
  }

  async #fetchWikipediaTitle(wikidataId: string): Promise<string | null> {
    const url = `${WIKIDATA_API_BASE}/${wikidataId}.json`;
    const response = await this.#fetch(url);
    if (!response.ok) {
      return null;
    }
    const data: WikidataResponse = await response.json();
    const entity = data.entities[wikidataId];
    return entity?.sitelinks?.enwiki?.title ?? null;
  }

  async #fetchSummary(articleTitle: string): Promise<WikipediaSummary | null> {
    const encodedTitle = encodeURIComponent(articleTitle.replace(/ /g, '_'));
    const url = `${WIKIPEDIA_API_BASE}/page/summary/${encodedTitle}`;
    const response = await this.#fetch(url);
    if (!response.ok) {
      return null;
    }
    return response.json();
  }

  async fetchArtistWikipediaData(
    relations: MusicBrainzRelation[],
  ): Promise<WikipediaSummary | null> {
    try {
      const wikidataId = this.#extractWikidataId(relations);
      if (!wikidataId) {
        return null;
      }

      const articleTitle = await this.#fetchWikipediaTitle(wikidataId);
      if (!articleTitle) {
        return null;
      }

      return await this.#fetchSummary(articleTitle);
    } catch {
      return null;
    }
  }
}
