import type {
  Album,
  AlbumRef,
  ArtistBio,
  ArtistRef,
  MetadataProvider,
  NuclearPlugin,
  NuclearPluginAPI,
  SearchParams,
  Track,
} from '@nuclearplayer/plugin-sdk';

import { MusicBrainzClient } from './client';
import { PROVIDER_ID, PROVIDER_NAME } from './config';
import {
  mapArtistSearchResult,
  mapArtistToArtistBio,
  mapRecordingSearchResult,
  mapReleaseGroupSearchResult,
  mapReleaseGroupToAlbumRef,
  mapReleaseToAlbum,
} from './mappers';
import { WikipediaClient } from './wikipedia';

const createProvider = (
  musicbrainz: MusicBrainzClient,
  wikipedia: WikipediaClient,
): MetadataProvider =>
  ({
    id: PROVIDER_ID,
    kind: 'metadata',
    name: PROVIDER_NAME,
    searchCapabilities: ['artists', 'albums', 'tracks'],
    artistMetadataCapabilities: ['artistBio', 'artistAlbums'],
    albumMetadataCapabilities: ['albumDetails'],

    async searchArtists(
      params: Omit<SearchParams, 'types'>,
    ): Promise<ArtistRef[]> {
      const result = await musicbrainz.searchArtists(
        params.query,
        params.limit,
      );
      return result.artists.map(mapArtistSearchResult);
    },

    async searchAlbums(
      params: Omit<SearchParams, 'types'>,
    ): Promise<AlbumRef[]> {
      const result = await musicbrainz.searchReleaseGroups(
        params.query,
        params.limit,
      );
      return result['release-groups'].map(mapReleaseGroupSearchResult);
    },

    async searchTracks(params: Omit<SearchParams, 'types'>): Promise<Track[]> {
      const result = await musicbrainz.searchRecordings(
        params.query,
        params.limit,
      );
      return result.recordings.map(mapRecordingSearchResult);
    },

    async fetchArtistBio(artistId: string): Promise<ArtistBio> {
      const artist = await musicbrainz.getArtist(artistId);
      const wikipediaData = await wikipedia.fetchArtistWikipediaData(
        artist.relations ?? [],
      );
      return mapArtistToArtistBio(artist, wikipediaData);
    },

    async fetchArtistAlbums(artistId: string): Promise<AlbumRef[]> {
      const result = await musicbrainz.browseArtistReleaseGroups(artistId);
      return result['release-groups'].map(mapReleaseGroupToAlbumRef);
    },

    async fetchAlbumDetails(albumId: string): Promise<Album> {
      const releaseGroup = await musicbrainz.getReleaseGroup(albumId);
      const releasesResult =
        await musicbrainz.browseReleaseGroupReleases(albumId);

      const release = releasesResult.releases[0];
      if (!release) {
        return mapReleaseToAlbum(releaseGroup, {
          id: '',
          title: releaseGroup.title,
          media: [],
        });
      }

      return mapReleaseToAlbum(releaseGroup, release);
    },
  }) satisfies MetadataProvider;

const plugin: NuclearPlugin = {
  onEnable(api: NuclearPluginAPI) {
    const musicbrainz = new MusicBrainzClient(api.Http.fetch);
    const wikipedia = new WikipediaClient(api.Http.fetch);
    api.Providers.register(createProvider(musicbrainz, wikipedia));
  },

  onDisable(api: NuclearPluginAPI) {
    api.Providers.unregister(PROVIDER_ID);
  },
};

export default plugin;
