import { COVER_ART_ARCHIVE_BASE } from './config';

export const releaseGroupCoverUrl = (releaseGroupMbid: string): string =>
  `${COVER_ART_ARCHIVE_BASE}/release-group/${releaseGroupMbid}/front-500`;

export const releaseGroupThumbnailUrl = (releaseGroupMbid: string): string =>
  `${COVER_ART_ARCHIVE_BASE}/release-group/${releaseGroupMbid}/front-250`;

export const releaseCoverUrl = (releaseMbid: string): string =>
  `${COVER_ART_ARCHIVE_BASE}/release/${releaseMbid}/front-500`;

export const releaseThumbnailUrl = (releaseMbid: string): string =>
  `${COVER_ART_ARCHIVE_BASE}/release/${releaseMbid}/front-250`;
