export const MUSICBRAINZ_API_BASE = 'https://musicbrainz.org/ws/2';
export const COVER_ART_ARCHIVE_BASE = 'https://coverartarchive.org';
export const WIKIPEDIA_API_BASE = 'https://en.wikipedia.org/api/rest_v1';
export const WIKIDATA_API_BASE =
  'https://www.wikidata.org/wiki/Special:EntityData';

export const PROVIDER_ID = 'musicbrainz.metadata';
export const PROVIDER_NAME = 'MusicBrainz';

export const USER_AGENT =
  'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36';

export const DEFAULT_SEARCH_LIMIT = 25;
export const DEFAULT_BROWSE_LIMIT = 100;
// MusicBrainz enforces 1 req/s; exceeding it blocks ALL requests (HTTP 503)
export const RATE_LIMIT_INTERVAL_MS = 1100;
