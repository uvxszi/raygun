# MusicBrainz Metadata Plugin for Nuclear

A metadata provider plugin that enables search, artist pages, and album details powered by [MusicBrainz](https://musicbrainz.org/), with artist biographies and images from Wikipedia.

## Features

- Search for artists, albums, and tracks
- Artist pages with biography, genres, and discography
- Album pages with tracklists and cover art
- Cover art from the [Cover Art Archive](https://coverartarchive.org/)
- Artist bios and images from Wikipedia (via Wikidata links)

## Limitations

- No top tracks for artists — MusicBrainz does not track popularity
- No similar/related artists — MusicBrainz does not have similarity data
- Artist images depend on a Wikidata link being present in MusicBrainz
- Discography is limited to the first 100 releases

## Installation

Install from the Nuclear plugin browser.

## License

AGPL-3.0-only
